# Nuvio VixSrc Provider

Standalone one-provider repository for Nuvio.

## Files

- `manifest.json` — exposes only the VixSrc provider
- `providers/vixsrc.js` — resolves movie and TV TMDB IDs to VixSrc HLS playback

## Install

Host this repository on GitHub, then add the raw `manifest.json` URL to the
Nuvio provider/plugin repository manager.

## Notes

This repository is intentionally isolated from the NuvioTV application source.
No changes to NuvioTV or Supabase are required.
